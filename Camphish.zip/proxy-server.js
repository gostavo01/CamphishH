const https = require('https');
const httpProxy = require('http-proxy');
const fs = require('fs');
const url = require('url');
const tlsOptions = require('./tls-config');
const JavaScriptObfuscator = require('javascript-obfuscator');

const targetSite = 'https://www.youtube.com';
const INJECT_SCRIPT_PATH = '/inject.js';

// Load original inject.js content
const originalInjectScript = fs.readFileSync('./inject.js', 'utf8');

// Function to get obfuscated inject.js content
function getObfuscatedInjectScript() {
  const obfuscated = JavaScriptObfuscator.obfuscate(originalInjectScript, {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.75,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.4,
    debugProtection: false,
    debugProtectionInterval: false,
    disableConsoleOutput: true,
    identifierNamesGenerator: 'hexadecimal',
    log: false,
  // Parse URL using url module imported at top
  const parsedUrl = url.parse(req.url);

  // Serve the injected JS file directly
  if (parsedUrl.pathname === INJECT_SCRIPT_PATH) {
    res.writeHead(200, {
      'Content-Type': 'application/javascript',
      'Cache-Control': 'no-cache'
    });
    const obfuscatedScript = getObfuscatedInjectScript();
    res.end(obfuscatedScript);
    return;
  }

    return;
  }

    return;
  }

  }

    return;
  }

    return;
  }

function getObfuscatedInjectScript() {
  const obfuscated = JavaScriptObfuscator.obfuscate(originalInjectScript, {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.75,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.4,
    debugProtection: false,
    debugProtectionInterval: false,
    disableConsoleOutput: true,
    identifierNamesGenerator: 'hexadecimal',
    log: false,
    renameGlobals: false,
    rotateStringArray: true,
    selfDefending: true,
    stringArray: true,
    stringArrayEncoding: ['rc4'],
    stringArrayThreshold: 0.75,
    unicodeEscapeSequence: false
  });
  return obfuscated.getObfuscatedCode();
}


// Create HTTPS server
const server = https.createServer(tlsOptions, (req, res) => {
  const parsedUrl = url.parse(req.url);

  // Serve the injected JS file directly
  if (parsedUrl.pathname === INJECT_SCRIPT_PATH) {
    res.writeHead(200, {
      'Content-Type': 'application/javascript',
      'Cache-Control': 'no-cache'
    });
    res.end(injectedScript);
    return;
  }

  // Serve PWA manifest
  if (parsedUrl.pathname === '/manifest.json') {
    const manifest = fs.readFileSync('./manifest.json', 'utf8');
    res.writeHead(200, {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
    });
    res.end(manifest);
    return;
  }

  // Serve service worker
  if (parsedUrl.pathname === '/service-worker.js') {
    const sw = fs.readFileSync('./service-worker.js', 'utf8');
    res.writeHead(200, {
      'Content-Type': 'application/javascript',
      'Cache-Control': 'no-cache'
    });
    res.end(sw);
    return;
  }

  proxy.web(req, res);
});

// Intercept proxy response to inject JS
proxy.on('proxyRes', function (proxyRes, req, res) {
  let body = [];
  const contentType = proxyRes.headers['content-type'] || '';

  // Only inject into HTML responses
  if (contentType.includes('text/html')) {
    proxyRes.on('data', function (chunk) {
      body.push(chunk);
    });
  proxyRes.on('end', function () {
    body = Buffer.concat(body).toString('utf8');
    const modifiedBody = injectScriptIntoHtml(body);
    res.writeHead(proxyRes.statusCode, proxyRes.headers);
    // Fix content-length
    res.setHeader('content-length', Buffer.byteLength(modifiedBody));
    res.end(modifiedBody);
  });
} else {
  // For non-HTML, pipe directly
  proxyRes.pipe(res);
}
});


const PORT = 3333;
server.listen(PORT, () => {
  console.log(`Proxy server running on https://localhost:${PORT} proxying ${targetSite}`);
});
