const fs = require('fs');

// Load TLS certificate and key
const tlsOptions = {
  key: fs.readFileSync('./certs/server.key'),
  cert: fs.readFileSync('./certs/server.crt'),
};

module.exports = tlsOptions;
